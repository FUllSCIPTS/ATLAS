"""Process-level ATLAS prototype: measured coupling switch and crash recovery.

A gateway process hosts the PaymentModule in-process (tight) or forwards
calls over HTTPS/mTLS to a separate module process (loose).  An open-loop
load generator drives the gateway; every timestamp is taken with
time.perf_counter().  Outputs ../results/prototype.json

Experiments
  bench      : per-call latency, in-process vs HTTP vs HTTPS+mTLS (loopback)
  switch     : tight->loose and loose->tight hand-over under load (30 reps each)
  recovery   : kill -9 / SIGSTOP of the loose module under load (30 reps each),
               ATLAS seven-step protocol vs a Kubernetes-like baseline
"""
import http.client, json, os, signal, socket, ssl, subprocess, sys, threading, time, uuid
from concurrent.futures import ThreadPoolExecutor
import numpy as np
HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
from module_server import PaymentModule

CERT = os.path.join(HERE, "certs")
OUT = os.path.join(HERE, "..", "results")
RATE = int(os.environ.get("PROTO_RATE", 300))
REPS = int(os.environ.get("PROTO_REPS", 30))
PORT0 = 18000


def make_certs():
    if os.path.exists(f"{CERT}/client.crt"):
        return
    os.makedirs(CERT, exist_ok=True)
    sh = lambda c: subprocess.run(c, shell=True, check=True, cwd=CERT, capture_output=True)
    sh("openssl req -x509 -newkey rsa:2048 -nodes -keyout ca.key -out ca.crt -days 30 -subj /CN=atlas-ca "
       "-addext basicConstraints=critical,CA:TRUE -addext keyUsage=critical,keyCertSign,cRLSign")
    for n in ("server", "client"):
        sh(f"openssl req -newkey rsa:2048 -nodes -keyout {n}.key -out {n}.csr -subj /CN={n}")
        open(f"{CERT}/{n}.ext", "w").write(
            "subjectAltName=IP:127.0.0.1\nbasicConstraints=CA:FALSE\n"
            "keyUsage=critical,digitalSignature,keyEncipherment\n"
            f"extendedKeyUsage={'serverAuth' if n == 'server' else 'clientAuth'}\n"
            "authorityKeyIdentifier=keyid\nsubjectKeyIdentifier=hash\n")
        sh(f"openssl x509 -req -in {n}.csr -CA ca.crt -CAkey ca.key -CAcreateserial -out {n}.crt -days 30 -extfile {n}.ext")


def client_ctx():
    ctx = ssl.create_default_context(cafile=f"{CERT}/ca.crt")
    ctx.load_cert_chain(f"{CERT}/client.crt", f"{CERT}/client.key")
    return ctx


class Remote:
    """Handle to a module process."""
    def __init__(self, port, tls=True):
        self.port, self.tls = port, tls
        self.ctx = client_ctx() if tls else None
        self.tl = threading.local()
        self.proc = None

    def spawn(self):
        self.proc = subprocess.Popen([sys.executable, "-u", os.path.join(HERE, "module_server.py"),
                                      str(self.port), CERT, "1" if self.tls else "0"],
                                     stdout=subprocess.PIPE, stderr=subprocess.DEVNULL)
        self.proc.stdout.readline()                    # READY
        self.tl = threading.local()
        t_end = time.perf_counter() + 20
        while True:                                    # readiness probe
            if self.proc.poll() is not None or time.perf_counter() > t_end:
                raise RuntimeError("module process failed to become ready")
            try:
                if self.get("/health", timeout=0.5)["ok"]:
                    return
            except Exception:
                time.sleep(0.01)

    def conn(self, timeout=2.0):
        c = getattr(self.tl, "c", None)
        if c is None:
            c = (http.client.HTTPSConnection("127.0.0.1", self.port, context=self.ctx, timeout=timeout)
                 if self.tls else http.client.HTTPConnection("127.0.0.1", self.port, timeout=timeout))
            self.tl.c = c
        return c

    def _req(self, method, path, body=None, timeout=2.0):
        c = self.conn(timeout)
        try:
            c.request(method, path, body=json.dumps(body).encode() if body is not None else None,
                      headers={"Content-Type": "application/json"})
            if c.sock is not None:
                c.sock.setsockopt(socket.IPPROTO_TCP, socket.TCP_NODELAY, 1)
            return json.loads(c.getresponse().read())
        except Exception:
            self.tl.c = None
            try: c.close()
            except Exception: pass
            raise

    def get(self, path, timeout=2.0):
        return self._req("GET", path, timeout=timeout)

    def post(self, path, body, timeout=2.0):
        return self._req("POST", path, body, timeout=timeout)

    def kill(self, sig=signal.SIGKILL):
        if self.proc and self.proc.poll() is None:
            self.proc.send_signal(sig)


class Gateway:
    def __init__(self, port, atlas=True):
        self.local = PaymentModule(); self.remote = Remote(port)
        self.mode = "tight"; self.atlas = atlas
        self.cv = threading.Condition(); self.barrier = False
        self.inflight = {"tight": 0, "loose": 0}
        self.circuit_open = False; self.buffer = []; self.buf_lock = threading.Lock()
        self.delta = []; self.delta_lock = threading.Lock()
        self.snap = None; self.snap_seq = 0; self.seq = 0
        self.acked = set(); self.ack_lock = threading.Lock()
        self.failure_event = threading.Event()
        self.unavailable = False          # baseline: endpoint removed, fail fast
        self.call_timeout = 0.5           # gateway per-call deadline (s)
        self.stop_drain = threading.Event()
        self.drain_ok = True              # cleared on a call failure, set again at rejoin
        threading.Thread(target=self.drainer, daemon=True).start()

    def drainer(self):
        """Re-delivers buffered requests whenever the circuit is closed."""
        while not self.stop_drain.wait(0.02):
            if self.circuit_open or self.mode != "loose":
                continue
            if not self.drain_ok:
                # a call failed: resume re-delivery only once the module answers a
                # health probe again (transient timeout) or after recovery (rejoin)
                try:
                    if self.remote.get("/health", timeout=0.3)["ok"]:
                        self.drain_ok = True
                except Exception:
                    pass
                continue
            with self.buf_lock:
                items, self.buffer = self.buffer, []
            for it in items:
                try:
                    self.remote.post("/call", {"key": it[0], "amount": it[1]}, timeout=2.0); it[3] = True
                except Exception:
                    it[3] = False
                it[2].set()

    # ------------------------------------------------------------ data path
    def handle(self, key, amount):
        with self.cv:
            while self.barrier:
                self.cv.wait()
            m = self.mode; self.inflight[m] += 1
        try:
            if m == "tight":
                res = self.local.call(key, amount); ok = True
            else:
                entry = [0, key, amount, None]
                with self.delta_lock:
                    self.seq += 1; entry[0] = self.seq; self.delta.append(entry)
                if self.unavailable:
                    ok = False
                elif self.circuit_open:
                    ok = self.enqueue(key, amount)
                else:
                    try:
                        try:
                            self.remote.post("/call", {"key": key, "amount": amount}, timeout=self.call_timeout)
                        except Exception:
                            if self.remote.proc.poll() is not None or self.circuit_open:
                                raise
                            self.remote.post("/call", {"key": key, "amount": amount},
                                             timeout=self.call_timeout)          # one retry, fresh conn
                        ok = True; entry[3] = time.perf_counter()
                    except Exception:
                        self.failure_event.set(); self.drain_ok = False
                        ok = self.enqueue(key, amount) if self.atlas else False
            if ok:
                with self.ack_lock:
                    self.acked.add(key)
            return ok
        finally:
            with self.cv:
                self.inflight[m] -= 1; self.cv.notify_all()

    def enqueue(self, key, amount, wait=30.0):
        ev = threading.Event(); item = [key, amount, ev, False]
        with self.buf_lock:
            self.buffer.append(item)
        ev.wait(wait)
        return item[3]

    # ------------------------------------------------------------ switching
    def to_loose(self):
        t = {"t0": time.perf_counter()}
        self.remote.spawn(); t["ready"] = time.perf_counter()
        with self.cv:
            self.barrier = True
            t["barrier"] = time.perf_counter()
            while self.inflight["tight"] > 0:
                self.cv.wait()
        t["drained"] = time.perf_counter()
        snap = self.local.snapshot()
        r = self.remote.post("/restore", snap, timeout=10)
        ok = tuple(r["checksum"]) == self.local.checksum()
        t["synced"] = time.perf_counter()
        with self.cv:
            if ok:
                self.mode = "loose"
                with self.delta_lock:
                    self.delta = []; self.snap = snap; self.snap_seq = self.seq
            else:                                              # rollback: stay tight
                self.remote.kill()
            self.barrier = False; self.cv.notify_all()
        t["flip"] = time.perf_counter(); t["ok"] = ok
        return t

    def to_tight(self):
        t = {"t0": time.perf_counter()}
        with self.cv:
            self.barrier = True
            while self.inflight["loose"] > 0:
                self.cv.wait()
        t["drained"] = time.perf_counter()
        snap = self.remote.get("/snapshot", timeout=10); self.local.restore(snap)
        ok = self.local.checksum() == tuple(self.remote.get("/health")["checksum"])
        t["synced"] = time.perf_counter()
        with self.cv:
            if ok:
                self.mode = "tight"
            self.barrier = False; self.cv.notify_all()
        t["flip"] = time.perf_counter(); t["ok"] = ok
        self.remote.kill(signal.SIGTERM); self.remote.proc.wait()
        return t

    # ------------------------------------------------------- Tier-2 snapshots
    def snapshotter(self, stop, period=2.0):
        while not stop.wait(period):
            if self.mode == "loose" and not self.circuit_open:
                try:
                    t_req = time.perf_counter()
                    with self.delta_lock:
                        s0 = self.seq
                    s = self.remote.get("/snapshot", timeout=1.0)
                    with self.delta_lock:
                        # an entry is certainly contained in the snapshot only if its call was
                        # acknowledged before the snapshot was requested; keep all others
                        self.delta = [d for d in self.delta if d[3] is None or d[3] >= t_req]
                        self.snap, self.snap_seq = s, s0
                except Exception:
                    pass


class Load:
    """Open-loop constant-rate load generator."""
    def __init__(self, gw, rate=RATE):
        self.gw = gw; self.rate = rate; self.rec = []; self.lock = threading.Lock()
        self.stop = threading.Event(); self.pool = ThreadPoolExecutor(64)

    def one(self, ts):
        key = uuid.uuid4().hex
        ok = self.gw.handle(key, 1)
        with self.lock:
            self.rec.append((ts, time.perf_counter(), ok))

    def run(self):
        t0 = time.perf_counter(); k = 0
        while not self.stop.is_set():
            ts = t0 + k / self.rate
            d = ts - time.perf_counter()
            if d > 0:
                time.sleep(d)
            self.pool.submit(self.one, ts); k += 1

    def start(self):
        self.th = threading.Thread(target=self.run, daemon=True); self.th.start(); return self

    def finish(self):
        self.stop.set(); self.th.join(); self.pool.shutdown(wait=True)
        return np.array([(a, b, c) for a, b, c in self.rec])


def pct(x, q):
    return float(np.percentile(x, q)) if len(x) else float("nan")


# ===================================================================== bench
def bench(n=3000):
    res = {}
    m = PaymentModule()
    lat = []
    for i in range(n):
        t = time.perf_counter(); m.call(uuid.uuid4().hex, 1); lat.append((time.perf_counter() - t) * 1000)
    res["in-process"] = lat
    for tls, name in ((False, "HTTP/1.1 keep-alive"), (True, "HTTPS + mutual TLS keep-alive")):
        r = Remote(PORT0 + (1 if tls else 0), tls=tls); r.spawn(); lat = []
        for i in range(n):
            t = time.perf_counter(); r.post("/call", {"key": uuid.uuid4().hex, "amount": 1})
            lat.append((time.perf_counter() - t) * 1000)
        res[name] = lat; r.kill(); r.proc.wait()
    # TLS handshake cost (new connection per call)
    r = Remote(PORT0 + 2, tls=True); r.spawn(); hs = []
    for i in range(300):
        r.tl.c = None
        t = time.perf_counter(); r.post("/call", {"key": uuid.uuid4().hex, "amount": 1})
        hs.append((time.perf_counter() - t) * 1000)
    r.kill(); r.proc.wait(); res["HTTPS + mTLS, new connection"] = hs
    return {k: dict(median_ms=pct(v, 50), p99_ms=pct(v, 99), mean_ms=float(np.mean(v)), n=len(v))
            for k, v in res.items()}


# ==================================================================== switch
def switch_exp(reps=REPS):
    out = {"to_loose": [], "to_tight": []}
    for k in range(reps):
        gw = Gateway(PORT0 + 10 + k)
        L = Load(gw).start(); time.sleep(1.5)
        a = gw.to_loose(); time.sleep(1.5)
        b = gw.to_tight(); time.sleep(1.0)
        R = L.finish()
        lat = (R[:, 1] - R[:, 0]) * 1000; ok = R[:, 2] == 1
        def window(t):
            s = (R[:, 0] >= t["t0"] - 0.0) & (R[:, 0] <= t["flip"] + 0.5)
            return lat[s]
        st = (R[:, 0] < a["t0"])
        for name, t in (("to_loose", a), ("to_tight", b)):
            out[name].append(dict(total_ms=(t["flip"] - t["t0"]) * 1000,
                                  spawn_ready_ms=((t["ready"] - t["t0"]) * 1000) if "ready" in t else 0.0,
                                  pause_ms=(t["flip"] - (t.get("barrier", t["t0"]))) * 1000,
                                  drain_ms=(t["drained"] - t.get("barrier", t["t0"])) * 1000,
                                  sync_ms=(t["synced"] - t["drained"]) * 1000,
                                  p99_window_ms=pct(window(t), 99), ok=bool(t["ok"])))
        # invariants: every acknowledged request applied exactly once
        final = gw.local.checksum()
        out.setdefault("invariants", []).append(dict(acked=len(gw.acked), applied=final[0],
                                                     failed=int((~ok).sum()), steady_p99_ms=pct(lat[st], 99)))
        print(f"switch rep {k}: to_loose {out['to_loose'][-1]['total_ms']:.0f} ms "
              f"pause {out['to_loose'][-1]['pause_ms']:.1f} ms; to_tight {out['to_tight'][-1]['total_ms']:.1f} ms",
              flush=True)
    return out


# ================================================================== recovery
def recovery_run(k, kind, atlas, probe_s=1.0, probe_k=3, ready_period=10.0):
    gw = Gateway(PORT0 + 100 + k, atlas=atlas); gw.to_loose()
    stop = threading.Event()
    threading.Thread(target=gw.snapshotter, args=(stop,), daemon=True).start()
    L = Load(gw).start(); time.sleep(2.5 + np.random.default_rng(k).uniform(0, 1))
    ts = {}
    ts["fail"] = time.perf_counter()
    gw.remote.kill(signal.SIGKILL if kind == "exit" else signal.SIGSTOP)
    # ---- 1 detect
    fails = 0; last_probe = time.perf_counter()
    while True:
        if gw.remote.proc.poll() is not None:              # exit observed by supervisor
            break
        if time.perf_counter() - last_probe >= probe_s:
            last_probe = time.perf_counter()
            try:
                gw.remote.get("/health", timeout=0.3); fails = 0
            except Exception:
                fails += 1
                if fails >= probe_k:
                    break
        time.sleep(0.005)
    ts["detect"] = time.perf_counter()
    # ---- 2 classify (exit code present -> C1 transient; no exit -> hang)
    cls = "C1-exit" if gw.remote.proc.poll() is not None else "C1-hang"
    ts["classify"] = time.perf_counter()
    # ---- 3 isolate (ATLAS: open circuit and buffer; baseline: endpoint removed, fail fast)
    if atlas:
        gw.circuit_open = True
    else:
        gw.unavailable = True
    ts["isolate"] = time.perf_counter()
    gw.remote.kill(signal.SIGKILL); gw.remote.proc.wait()
    # ---- 4 restart (process re-created and ready)
    gw.remote.spawn(); ts["restart"] = time.perf_counter()
    # ---- 5 restore: Tier-2 snapshot (+ Tier-1 replay for ATLAS only)
    with gw.delta_lock:
        snap = gw.snap; deltas = list(gw.delta)
    gw.remote.post("/restore", snap, timeout=10)
    replayed = 0
    if atlas:
        for _, key, amt, _d in deltas:
            gw.remote.post("/call", {"key": key, "amount": amt}); replayed += 1
    ts["restore"] = time.perf_counter()
    # ---- 6 verify (ATLAS: health + checksum; baseline: k8s readiness probe tick)
    if atlas:
        ver_ok = gw.remote.get("/health")["ok"]
    else:
        time.sleep(np.random.default_rng(k + 7).uniform(0, ready_period))
    ts["verify"] = time.perf_counter()
    # ---- 7 rejoin (ATLAS: close circuit, drain buffer in arrival order)
    if atlas:
        gw.drain_ok = True; gw.circuit_open = False
        while True:
            with gw.buf_lock:
                empty = not gw.buffer
            if empty:
                break
            time.sleep(0.005)
    else:
        gw.unavailable = False
    ts["rejoin"] = time.perf_counter()
    flushed = 0
    time.sleep(1.5)
    R = L.finish(); stop.set(); gw.stop_drain.set()
    final = gw.remote.get("/health")["checksum"]
    gw.remote.kill(); gw.remote.proc.wait()
    lat = (R[:, 1] - R[:, 0]) * 1000; ok = R[:, 2] == 1
    during = (R[:, 0] >= ts["fail"]) & (R[:, 0] <= ts["rejoin"])
    with gw.ack_lock:
        acked = set(gw.acked)
    return dict(kind=cls, atlas=atlas,
                mttd_ms=(ts["detect"] - ts["fail"]) * 1000,
                mttr_ms=(ts["rejoin"] - ts["fail"]) * 1000,
                steps_ms={s: (ts[s] - ts[p]) * 1000 for p, s in zip(
                    ["fail", "detect", "classify", "isolate", "restart", "restore", "verify"],
                    ["detect", "classify", "isolate", "restart", "restore", "verify", "rejoin"])},
                applied_but_failed=max(0, int(final[0]) - len(acked)),
                requests_during=int(during.sum()), failed=int((~ok).sum()),
                buffered=int(sum(1 for x in R if x[0] >= ts["isolate"] and x[0] <= ts["rejoin"])) if atlas else 0,
                replayed=replayed,
                acked=len(acked), applied=int(final[0]),
                lost_acked=max(0, len(acked) - int(final[0])),
                p99_during_ms=pct(lat[during & ok], 99), max_during_ms=float(lat[during & ok].max()) if (during & ok).any() else float("nan"))


def recovery_exp(reps=REPS):
    out = {}
    for kind in ("exit", "hang"):
        for atlas in (True, False):
            key = f"{'ATLAS' if atlas else 'k8s-like'}:{kind}"
            out[key] = []
            for k in range(reps):
                r = recovery_run(k + (0 if atlas else 1000) + (0 if kind == "exit" else 2000), kind, atlas)
                out[key].append(r)
                print(f"{key} rep {k}: MTTR {r['mttr_ms']:.0f} ms, failed {r['failed']}, lost {r['lost_acked']}, "
                      f"buffered {r['buffered']}", flush=True)
    return out


if __name__ == "__main__":
    make_certs()
    res = {"rate_rps": RATE, "reps": REPS, "host": dict(cpus=os.cpu_count(), python=sys.version.split()[0])}
    which = sys.argv[1:] or ["bench", "switch", "recovery"]
    path = os.path.join(OUT, "prototype.json")
    if os.path.exists(path):
        res.update(json.load(open(path)))
    if "bench" in which:
        res["bench"] = bench(); print(json.dumps(res["bench"], indent=1), flush=True)
    if "switch" in which:
        res["switch"] = switch_exp()
    if "recovery" in which:
        res["recovery"] = recovery_exp()
    json.dump(res, open(path, "w"), indent=1)
