"""A stateful 'Payment' module served over HTTPS with mutual TLS.

The same PaymentModule class is used in-process (tight mode) by the gateway,
so the two execution modes run identical business logic.
Endpoints: POST /call, GET /health, GET /snapshot, POST /restore
"""
import json, ssl, sys, threading
from http.server import ThreadingHTTPServer, BaseHTTPRequestHandler


class PaymentModule:
    """Idempotent payment ledger: a request with an already-seen key is
    acknowledged but not applied again (at-most-once application)."""
    def __init__(self):
        self.lock = threading.Lock(); self.seen = set(); self.total = 0; self.count = 0

    def call(self, key, amount):
        with self.lock:
            if key in self.seen:
                return {"ok": True, "dup": True}
            self.seen.add(key); self.total += amount; self.count += 1
            # a little CPU work to emulate business logic (~0.2 ms)
            x = 0
            for i in range(800):
                x += i * i
            return {"ok": True, "dup": False}

    def snapshot(self):
        with self.lock:
            return {"seen": sorted(self.seen), "total": self.total, "count": self.count}

    def restore(self, s):
        with self.lock:
            self.seen = set(s["seen"]); self.total = s["total"]; self.count = s["count"]

    def checksum(self):
        with self.lock:
            return (self.count, self.total, len(self.seen))


MOD = PaymentModule()


class H(BaseHTTPRequestHandler):
    protocol_version = "HTTP/1.1"

    def setup(self):
        super().setup()
        import socket
        self.request.setsockopt(socket.IPPROTO_TCP, socket.TCP_NODELAY, 1)   # avoid Nagle/delayed-ACK stalls

    def log_message(self, *a):
        pass

    def _send(self, obj, code=200):
        b = json.dumps(obj).encode()
        self.send_response(code); self.send_header("Content-Type", "application/json")
        self.send_header("Content-Length", str(len(b))); self.end_headers(); self.wfile.write(b)

    def do_GET(self):
        if self.path == "/health":
            self._send({"ok": True, "checksum": MOD.checksum()})
        elif self.path == "/snapshot":
            self._send(MOD.snapshot())
        else:
            self._send({"err": "nf"}, 404)

    def do_POST(self):
        n = int(self.headers.get("Content-Length", 0)); body = json.loads(self.rfile.read(n) or b"{}")
        if self.path == "/call":
            self._send(MOD.call(body["key"], body["amount"]))
        elif self.path == "/restore":
            MOD.restore(body); self._send({"ok": True, "checksum": MOD.checksum()})
        else:
            self._send({"err": "nf"}, 404)


def serve(port, certdir, tls=True):
    srv = ThreadingHTTPServer(("127.0.0.1", port), H)
    srv.daemon_threads = True
    if tls:
        ctx = ssl.SSLContext(ssl.PROTOCOL_TLS_SERVER)
        ctx.load_cert_chain(f"{certdir}/server.crt", f"{certdir}/server.key")
        ctx.load_verify_locations(f"{certdir}/ca.crt"); ctx.verify_mode = ssl.CERT_REQUIRED
        srv.socket = ctx.wrap_socket(srv.socket, server_side=True)
    print("READY", flush=True)
    srv.serve_forever()


if __name__ == "__main__":
    serve(int(sys.argv[1]), sys.argv[2], tls=(sys.argv[3] == "1") if len(sys.argv) > 3 else True)
