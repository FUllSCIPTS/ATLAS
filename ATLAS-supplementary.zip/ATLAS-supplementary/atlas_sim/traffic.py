"""Synthetic workload and telemetry generators used in the ATLAS evaluation.

All generators are deterministic given a seed.  Equations follow the
manuscript (Section "Normal Traffic Generation" and
"Flash-Sale Traffic Generation").
"""
import numpy as np

MIN_PER_DAY = 1440

# Six-service e-commerce application -------------------------------------
SERVICES = ["Gateway", "Catalogue", "Cart", "Inventory", "Payment", "Order"]
VISIT = np.array([1.00, 1.00, 0.45, 0.35, 0.18, 0.15])      # visit ratio per request
DEMAND_MS = np.array([0.5, 2.0, 1.5, 1.5, 4.0, 3.0])          # core-ms per visit


def ecommerce_trace(days=365, seed=0, base=600.0, a_d=350.0, a_w=120.0,
                    noise=60.0, n_events=48, amp=(4000, 8000), dur=(20, 90),
                    peak_frac=1/3, trend=0.0, bursts=0, burst_amp=(500, 3000),
                    phase_h=0.0, scale=1.0):
    """Return (rps[minute], event_mask[minute], events list).

    trend     : fractional growth of the baseline over the trace (non-stationarity)
    bursts    : number of short heavy-tailed micro-bursts (irregular traffic)
    phase_h   : time-zone shift of the daily cycle (cross-node tests)
    scale     : multiplicative node scale (cross-node tests)
    """
    rng = np.random.default_rng(seed)
    n = days * MIN_PER_DAY
    t = np.arange(n)
    h = ((t / 60.0) + phase_h) % 24
    w = (t / MIN_PER_DAY) % 7
    b = base * (1 + trend * t / n)
    r = (b + a_d * np.sin(2 * np.pi * h / 24 - 2 * np.pi * 9 / 24)
         + a_w * np.sin(2 * np.pi * w / 7 - 2 * np.pi * 3 / 7)
         + rng.normal(0, noise, n))
    mask = np.zeros(n, dtype=np.int8)
    events = []
    # flash sales: min 48 h separation
    starts = []
    tries = 0
    while len(starts) < n_events and tries < 100000:
        tries += 1
        s = int(rng.integers(MIN_PER_DAY, n - 200))
        if all(abs(s - x) >= 2 * MIN_PER_DAY for x in starts):
            starts.append(s)
    for s in sorted(starts):
        A = rng.uniform(*amp)
        D = int(rng.uniform(*dur))
        mu = s + peak_frac * D
        sig = max(D / 6.0, 2.0)
        tt = np.arange(s, min(s + D + 1, n))
        r[tt] += A * np.exp(-((tt - mu) ** 2) / (2 * sig ** 2))
        mask[tt] = 1
        events.append((s, D, A))
    if bursts:
        for _ in range(bursts):
            s = int(rng.integers(0, n - 15))
            L = int(rng.integers(1, 11))
            A = min(burst_amp[0] * (rng.pareto(1.5) + 1), burst_amp[1])
            r[s:s + L] += A
    r = np.maximum(r, 0) * scale
    return r.astype(np.float32), mask, events


def fleet_trace(days=63, seed=0):
    """Connected-vehicle fleet event rate (events/s) at 1-min resolution.

    Day-to-day variability: peak-time jitter, amplitude jitter, weekends,
    'weather' days (delayed and wider surge) and 4% multiplicative noise.
    """
    rng = np.random.default_rng(seed)
    out, meta = [], []
    for d in range(days):
        m = np.arange(MIN_PER_DAY)
        wd = d % 7
        weekend = wd >= 5
        weather = rng.random() < 0.12
        c = 480 + rng.normal(0, 10) + (rng.uniform(20, 40) if weather else 0)
        sd = 45 * (1.4 if weather else 1.0)
        A = 38000 * rng.uniform(0.85, 1.15) * (0.35 if weekend else 1.0)
        plateau = 12000 * rng.uniform(0.9, 1.1) * (0.5 if weekend else 1.0)
        base = 3200 * rng.uniform(0.95, 1.05)
        rate = (base + A * np.exp(-((m - c) ** 2) / (2 * sd ** 2))
                + plateau / (1 + np.exp(-(m - 560) / 15)) * (1 / (1 + np.exp((m - 1110) / 25))))
        rate *= 1 + rng.normal(0, 0.04, MIN_PER_DAY)
        out.append(np.maximum(rate, 0))
        meta.append(dict(day=d, weekend=bool(weekend), weather=bool(weather)))
    return np.concatenate(out).astype(np.float32), meta


def calendar_features(n, phase_h=0.0):
    t = np.arange(n)
    h = ((t / 60.0) + phase_h) % 24
    w = (t / MIN_PER_DAY) % 7
    return np.stack([np.sin(2 * np.pi * h / 24), np.cos(2 * np.pi * h / 24),
                     np.sin(2 * np.pi * w / 7), np.cos(2 * np.pi * w / 7)], 1).astype(np.float32)


def telemetry(r, rng, cores=16.0, anomaly=None):
    """Eight telemetry fields derived from the request rate (monolith view).

    Returns array [rps, cpu, mem, lat, err, queue, net, disk].
    `anomaly` in {None,'cpu','mem','down','flood','netdisk'} perturbs the state.
    """
    r = np.asarray(r, dtype=float)
    n = r.shape[0]
    D = float((VISIT * DEMAND_MS).sum())
    rho = np.clip(r * D / 1000.0 / cores, 0, 0.98)
    cpu = np.clip(8 + 88 * rho + rng.normal(0, 3, n), 0, 100)
    mem = np.clip(35 + 30 * rho + rng.normal(0, 2, n), 0, 100)
    lat = 12 + D / (1 - rho) + rng.normal(0, 2, n)
    err = np.clip(0.002 + 0.02 * np.maximum(rho - 0.9, 0) + rng.normal(0, 0.0007, n), 0, 1)
    q = np.maximum(0, 5 + 400 * np.maximum(rho - 0.8, 0) + rng.normal(0, 2, n))
    net = np.maximum(0, 0.004 * r + rng.normal(0, 0.3, n))
    disk = np.maximum(0.1, 2 + rng.normal(0, 0.3, n))
    X = np.stack([r, cpu, mem, lat, err, q, net, disk], 1)
    if anomaly == "cpu":
        X[:, 1] = rng.uniform(85, 100, n); X[:, 3] = rng.uniform(600, 1000, n)
        X[:, 5] *= rng.uniform(2, 4, n); X[:, 4] += rng.uniform(0.01, 0.05, n)
    elif anomaly == "mem":
        X[:, 2] = rng.uniform(90, 100, n); X[:, 5] = X[:, 5] * rng.uniform(3, 10, n) + 30
    elif anomaly == "down":
        X[:, 1] = rng.uniform(20, 45, n); X[:, 4] = rng.uniform(0.05, 0.3, n)
        X[:, 3] = rng.uniform(5, 15, n)
    elif anomaly == "flood":
        f = rng.uniform(5, 15, n)
        X[:, 0] *= f; X[:, 1] = np.clip(X[:, 1] * 1.8, 0, 100); X[:, 3] *= rng.uniform(3, 8, n)
        X[:, 5] = X[:, 5] * 5 + 50; X[:, 6] *= f
    elif anomaly == "netdisk":
        X[:, 6] *= rng.uniform(3, 8, n); X[:, 7] = rng.uniform(15, 60, n); X[:, 3] += rng.uniform(30, 120, n)
    return X.astype(np.float32)
