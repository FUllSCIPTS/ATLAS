"""Discrete-time (1 s) cluster simulator with event-level (continuous-time)
failure/recovery timestamps.

Architectures / policies
  monolith        all modules in one 16-core process, fixed capacity
  microservices   all modules as pods, reactive HPA (k8s defaults)
  hansel          Bi-LSTM forecast + proactive & reactive horizontal scaling (always loose)
  phybrid         Bi-LSTM forecast + burst detector + horizontal & vertical scaling
  xscale          Bi-LSTM forecast + proactive scaling + burst handling + cloud forwarding
  atlas           BIP-driven tight/hybrid/loose coupling + self-healing

Every modelling assumption is a field of `Params` and is reported in the paper.
"""
import math, time
from dataclasses import dataclass, field, replace
import numpy as np
from .traffic import VISIT, DEMAND_MS, SERVICES


@dataclass
class Params:
    visit: np.ndarray = field(default_factory=lambda: VISIT.copy())
    demand: np.ndarray = field(default_factory=lambda: DEMAND_MS.copy())  # core-ms / visit
    mono_cores: float = 16.0
    pod_cores: float = 1.0
    sidecar_cores: float = 0.1          # per pod (Envoy)
    svc_fixed_cores: float = 1.0        # per extracted service: datastore/broker share
    min_rep: int = 2
    max_rep: int = 40
    base_ms: float = 10.0               # I/O and database time per request
    net_ms: float = 4.0                 # median per remote call (lognormal, sigma .5)
    startup_s: tuple = (8.0, 30.0)      # new pod start-up (uniform)
    mono_start_s: tuple = (30.0, 60.0)  # restarting the monolith process
    restart_s: tuple = (2.0, 6.0)       # warm container restart (image cached)
    sla_ms: float = 200.0
    timeout_s: float = 2.0
    hpa_target: float = 0.70
    hpa_period: float = 15.0
    hpa_down_window: float = 300.0
    net_cost_core_s: float = 2e-5       # core-seconds-equivalent per remote call
    cloud_ms: tuple = (20.0, 45.0)
    cloud_price: float = 1.5            # relative core price of forwarded capacity
    crash_rho: float = 1.15             # sustained overload -> process crash
    crash_hold_s: float = 30.0
    manual_mttr_s: tuple = (300.0, 900.0)
    # ATLAS
    decision_s: float = 5.0
    alpha: float = 1.0; beta: float = 1.0; gamma: float = 1.0
    switch_pen: float = 0.05            # switching cost weight (fraction of J_ref per module change)
    rho_max: float = 0.85               # latency-SLA proxy for the monolith in the BIP
    down_dwell_s: float = 300.0         # hysteresis: dwell before merging modules back
    barrier_ms: float = 40.0            # state hand-over pause (measured in prototype)
    probe_s: float = 1.0; probe_k: int = 3
    classify_s: float = 0.05
    restore_s: tuple = (0.3, 1.5)
    verify_s: tuple = (1.0, 2.0)
    canary_s: float = 3.0
    k8s_probe_s: float = 10.0; k8s_k: int = 3
    buffer_cap: int = 200000
    anomaly_emergency: float = 0.9
    anomaly_alert: float = 0.7
    ref_lam: float = 650.0              # nominal load used to normalise the BIP terms
    p0: float = 1e-4                    # baseline crash probability per decision epoch
    p_a: float = 0.02                   # anomaly-driven increment
    p_rho: float = 1e-3                 # overload-driven increment
    a_min: float = 0.99                 # availability constraint per decision epoch
    gamma_scale: float = 0.01           # effective risk weight = gamma * gamma_scale


class Recovery:
    """Continuous-time recovery timeline; outage(t) gives the unavailable
    fraction of second [t, t+1)."""
    def __init__(self, t_fail, steps, buffered):
        self.t_fail = t_fail; self.steps = steps; self.buffered = buffered
        self.t_detect = t_fail + steps["detect"]
        self.t_end = t_fail + sum(steps.values())

    def overlap(self, t):
        a, b = max(t, self.t_fail), min(t + 1, self.t_end)
        return max(0.0, b - a)


def heal_steps(p, rng, mode, pod=True, kind="exit"):
    """Step durations (s) of one recovery.  kind='exit': the process terminates
    (observed by the container runtime within ~0.5 s); kind='hang': the process
    stays alive but stops answering, so only health probes can detect it."""
    if mode == "atlas":
        det = rng.uniform(0.2, 0.8) if kind == "exit" else \
            p.probe_s * (p.probe_k - 1) + rng.uniform(0, p.probe_s) + 0.2
        st = dict(detect=det, classify=p.classify_s, isolate=0.1,
                  restart=rng.uniform(*p.restart_s) if pod else rng.uniform(*p.mono_start_s),
                  restore=rng.uniform(*p.restore_s), verify=rng.uniform(*p.verify_s),
                  canary=p.canary_s)
    elif mode == "k8s":   # kubelet restart + readiness probe (period 10 s) + endpoint update
        det = rng.uniform(0.2, 0.8) if kind == "exit" else \
            p.k8s_probe_s * (p.k8s_k - 1) + rng.uniform(0, p.k8s_probe_s) + 1.0
        st = dict(detect=det, restart=rng.uniform(*p.restart_s) if pod else rng.uniform(*p.mono_start_s),
                  readiness=rng.uniform(0, p.k8s_probe_s), endpoints=rng.uniform(1, 2))
    else:  # manual
        st = dict(detect=rng.uniform(60, 180), restart=rng.uniform(*p.manual_mttr_s))
    return st


class Sim:
    def __init__(self, policy, lam, fc5, p=None, seed=0, opts=None, failure=None, anomaly=None,
                 iforest=None):
        self.p = p or Params(); self.policy = policy; self.lam = lam; self.fc5 = fc5
        self.rng = np.random.default_rng(seed); self.o = dict(forecast=True, anomaly=True, bip=True,
                                                               hybrid=True, heal="atlas", hysteresis=True)
        self.o.update(opts or {})
        if failure is None:
            failure = []
        self.failures = sorted([dict(f) for f in (failure if isinstance(failure, list) else [failure])],
                               key=lambda f: f["t"])
        self.failure = None
        self.anomaly = anomaly; self.iforest = iforest
        n = len(self.p.visit); self.n = n
        loose_all = policy in ("microservices", "hansel", "phybrid", "xscale")
        self.c = np.ones(n, int) if loose_all else np.zeros(n, int)
        self.rep = np.where(self.c == 1, self.p.min_rep, 0).astype(float)
        self.pending = [[] for _ in range(n)]          # ready times of starting pods
        self.cores = np.full(n, self.p.pod_cores)       # per-pod cores (vertical scaling)
        self.mono_on = not loose_all
        self.mono_down_until = -1
        self.extract_ready = {}                          # module -> time pods become ready
        self.last_up = -1e9; self.down_since = None; self.prev_proposal = None
        self.overload_s = 0.0
        self.demand_est = self.p.demand.copy()
        self.backlog_m = 0.0; self.backlog = np.zeros(n)
        self.rec = None; self.buffer = 0.0; self.flush = 0.0
        self.log = []; self.transitions = 0; self.dec_ms = []
        self.last_scale = -1e9; self.last_down = np.full(n, -1e9)
        self.anom_flag = 0.0

    # ----------------------------------------------------------- helpers
    def demand(self, t):
        d = self.p.demand.copy()
        if self.anomaly and self.anomaly["t0"] <= t < self.anomaly["t0"] + self.anomaly["dur"]:
            d[self.anomaly["module"]] *= self.anomaly["factor"]
        return d

    def capacity_needed(self, lam, d, i, target):
        return max(self.p.min_rep, math.ceil(lam * self.p.visit[i] * d[i] / 1000.0 / (target * self.cores[i])))

    def eval_config(self, c, lam, d, p_crash):
        """Predicted steady state of configuration c at load lam (used by BIP)."""
        p = self.p; v = self.p.visit
        tight = c == 0
        Dm = float((v * d)[tight].sum())
        rho_m = lam * Dm / 1000.0 / p.mono_cores if tight.any() else 0.0
        if rho_m >= 0.98:
            L = 1e4
        else:
            L = p.base_ms + (Dm / (1 - rho_m) if tight.any() else 0.0)
            L += float((v * (d / (1 - p.hpa_target) + p.net_ms))[~tight].sum())
        reps = np.array([self.capacity_needed(lam, d, i, p.hpa_target) if c[i] else 0 for i in range(self.n)])
        C = (p.mono_cores if tight.any() else 0.0) + float((reps * (p.pod_cores + p.sidecar_cores)).sum()) \
            + c.sum() * p.svc_fixed_cores + lam * float(v[~tight].sum()) * p.net_cost_core_s
        phi = float(v[tight].max()) if tight.any() else 0.0
        blast = np.where(tight, phi, v)
        R = float((p_crash * blast).sum()) * lam
        A = 1.0 - float((p_crash * blast).sum())
        return L, C, R, A, rho_m, reps

    def eval_all(self, CM, lam, d, p_crash):
        """Vectorised eval_config over all candidate configurations CM [K,n]."""
        p = self.p; v = p.visit
        tight = CM == 0
        Dm = (tight * (v * d)).sum(1)
        anyt = tight.any(1)
        rho_m = np.where(anyt, lam * Dm / 1000.0 / p.mono_cores, 0.0)
        Lm = np.where(anyt, Dm / (1 - np.minimum(rho_m, 0.97)), 0.0)
        L = p.base_ms + Lm + ((~tight) * (v * (d / (1 - p.hpa_target) + p.net_ms))).sum(1)
        L = np.where(rho_m >= 0.98, 1e4, L)
        need = np.maximum(p.min_rep, np.ceil(lam * v * d / 1000.0 / (p.hpa_target * self.cores)))
        reps = CM * need[None, :]
        C = np.where(anyt, p.mono_cores, 0.0) + (reps * (p.pod_cores + p.sidecar_cores)).sum(1) \
            + CM.sum(1) * p.svc_fixed_cores + lam * ((~tight) * v).sum(1) * p.net_cost_core_s
        phi = np.where(anyt, (tight * v).max(1), 0.0)
        blast = np.where(tight, phi[:, None], v[None, :])
        # crash probability per decision epoch depends on the utilisation of the
        # host that runs the module: the monolith (tight) or its own pods (loose)
        rho_host = np.where(tight, rho_m[:, None], p.hpa_target)
        P = p_crash[None, :] + p.p_rho / (1 + np.exp(-(rho_host - 0.9) * 20))
        risk = (P * blast).sum(1)
        return L, C, risk * lam, 1.0 - risk, rho_m, reps

    def bip(self, t, lam_star, a_score):
        """Exact solution of the coupling BIP by enumeration (n <= 10) with a
        switching-cost term; returns c* (vectorised over all 2^n candidates)."""
        p = self.p; t0 = time.perf_counter()
        if not hasattr(self, "CM"):
            K = 2 ** self.n
            self.CM = np.array([[(k >> i) & 1 for i in range(self.n)] for k in range(K)])
            if not self.o["hybrid"]:
                s_ = self.CM.sum(1); self.CM = self.CM[(s_ == 0) | (s_ == self.n)]
            L0, C0, _, _, _, _ = self.eval_config(np.zeros(self.n, int), p.ref_lam, p.demand, np.full(self.n, 1e-3))
            self.ref = (L0, C0, p.ref_lam * 1e-3)
        d = self.demand_est
        p_crash = np.full(self.n, p.p0)
        if self.anom_module >= 0:
            p_crash[self.anom_module] += p.p_a / (1 + np.exp(-(a_score - 0.7) * 20))
        L, C, R, A, rho_m, reps = self.eval_all(self.CM, lam_star, d, p_crash)
        L0, C0, R0 = self.ref
        J = p.alpha * L / L0 + p.beta * C / C0 + p.gamma * p.gamma_scale * R / R0 \
            + p.switch_pen * np.abs(self.CM - self.c[None, :]).sum(1)
        ok = (rho_m <= p.rho_max) & (L <= p.sla_ms) & (reps <= p.max_rep).all(1) & (A >= p.a_min)
        if ok.any():
            J = np.where(ok, J, np.inf); bc = self.CM[int(np.argmin(J))].copy()
        else:
            bc = np.ones(self.n, int)
        self.dec_ms.append((time.perf_counter() - t0) * 1000)
        return bc

    def apply(self, t, cnew):
        """Start transitions: extraction needs pods ready (dual-run until then);
        merging back is immediate if monolith is up, otherwise monolith restarts."""
        p = self.p
        for i in range(self.n):
            if cnew[i] == 1 and self.c[i] == 0 and i not in self.extract_ready:
                need = self.capacity_needed(max(self.lam[min(int(t), len(self.lam) - 1)], self.fc_at(t)),
                                            self.demand_est, i, p.hpa_target)
                ready = t + self.rng.uniform(*p.startup_s)
                self.extract_ready[i] = ready
                self.pending[i] += [ready] * need
            elif cnew[i] == 0 and self.c[i] == 1:
                if not self.mono_on:
                    self.mono_on = True
                    self.mono_ready = t + self.rng.uniform(*p.mono_start_s)
                    self.merge_at = getattr(self, "merge_at", {}); self.merge_at[i] = self.mono_ready
                else:
                    self.c[i] = 0; self.rep[i] = 0; self.pending[i] = []; self.transitions += 1
                    self.extract_ready.pop(i, None)
        for i in range(self.n):        # cancel extraction no longer wanted
            if cnew[i] == 0 and i in self.extract_ready:
                self.extract_ready.pop(i); self.pending[i] = []

    def fc_at(self, t):
        m = int(t // 60)
        return float(self.fc5[min(m, len(self.fc5) - 1)])

    # ---------------------------------------------------------- autoscalers
    def hpa(self, t, lam, d, predictive=False, vertical=False, burst=False):
        p = self.p
        if t - self.last_scale < p.hpa_period:
            return
        self.last_scale = t
        lam_p = self.fc_at(t) if predictive else lam
        surge = burst and lam > 1.3 * max(self.prev_lam, 1)
        for i in range(self.n):
            if self.c[i] == 0:
                continue
            cur = self.rep[i]
            util = lam * p.visit[i] * d[i] / 1000.0 / max(cur * self.cores[i], 1e-9)
            want = max(math.ceil(cur * util / p.hpa_target), p.min_rep)
            if predictive:
                want = max(want, self.capacity_needed(lam_p, d, i, p.hpa_target))
            if surge:
                want = max(want, math.ceil(want * 1.5))
            if vertical:
                # joint horizontal+vertical sizing: smallest pod size in {1,2,4}
                # cores that keeps the replica count <= 8, then replicas for it
                tot_cores = want * self.cores[i]
                size = next((c_ for c_ in (1.0, 2.0, 4.0) if tot_cores / c_ <= 8), 4.0)
                if size != self.cores[i] and (size > self.cores[i] or t - self.last_down[i] >= p.hpa_down_window):
                    self.cores[i] = size                     # in-place resize (no restart)
                want = max(math.ceil(tot_cores / self.cores[i]), p.min_rep)
            want = min(want, p.max_rep)
            tot = cur + len(self.pending[i])
            if want > tot:
                self.pending[i] += [t + self.rng.uniform(*p.startup_s)] * int(want - tot)
            elif want < cur and t - self.last_down[i] >= p.hpa_down_window:
                self.rep[i] = want; self.pending[i] = []; self.last_down[i] = t
        self.prev_lam = lam

    # ----------------------------------------------------------------- run
    def run(self):
        p = self.p; T = len(self.lam); rng = self.rng
        self.prev_lam = self.lam[0]; self.anom_module = -1
        net = rng.lognormal(math.log(p.net_ms), 0.5, T)
        out = dict(lat=np.zeros(T), lam=np.zeros(T), viol=np.zeros(T), fail=np.zeros(T),
                   cost=np.zeros(T), mode=np.zeros(T, int))
        a_score = 0.0
        for t in range(T):
            lam = float(self.lam[t]); d = self.demand(t)
            # pods becoming ready
            for i in range(self.n):
                rd = [x for x in self.pending[i] if x <= t]
                if rd:
                    self.rep[i] += len(rd); self.pending[i] = [x for x in self.pending[i] if x > t]
                if i in self.extract_ready and self.extract_ready[i] <= t:
                    self.c[i] = 1; self.extract_ready.pop(i); self.transitions += 1
                    self.barrier = p.barrier_ms
            mg = getattr(self, "merge_at", {})
            for i in list(mg):
                if mg[i] <= t:
                    self.c[i] = 0; self.rep[i] = 0; self.pending[i] = []; mg.pop(i); self.transitions += 1
            if self.c.sum() == self.n and self.mono_on and self.policy == "atlas" and not mg:
                self.mono_on = False                      # fully loose: release monolith
            # demand estimate (EWMA, tau = 300 s): slow profile used by BIP
            self.demand_est += (d - self.demand_est) / 300.0
            # ---- decisions
            if self.policy == "atlas" and t % int(p.decision_s) == 0:
                fc = self.fc_at(t) if self.o["forecast"] else lam
                lam_star = max(lam, fc)
                if self.o["anomaly"] and self.iforest is not None:
                    a_score = self.score(t, lam, d)
                if self.o["bip"]:
                    prop = self.bip(t, lam_star, a_score)
                else:
                    prop = self.fsm_thresholds(lam_star)
                if self.o["anomaly"] and a_score >= p.anomaly_emergency:
                    prop = np.ones(self.n, int)
                elif self.o["anomaly"] and a_score >= p.anomaly_alert and self.anom_module >= 0:
                    prop = prop.copy(); prop[self.anom_module] = 1
                # hysteresis: merging back only after the lower configuration persisted
                if self.o["hysteresis"] and (prop < self.c).any():
                    if self.down_since is None or not np.array_equal(prop, self.prev_proposal):
                        self.down_since = t; self.prev_proposal = prop
                    if t - self.down_since < p.down_dwell_s:
                        prop = np.maximum(prop, self.c)
                else:
                    self.down_since = None
                self.apply(t, prop)
            if self.policy in ("microservices", "hansel", "phybrid", "xscale", "atlas"):
                self.hpa(t, lam, d, predictive=self.policy in ("hansel", "phybrid", "xscale", "atlas") and self.o["forecast"],
                         vertical=self.policy == "phybrid", burst=self.policy in ("phybrid", "xscale"))
            # ---- failure injection (continuous time)
            if self.rec is None and self.failures and t >= int(self.failures[0]["t"]):
                self.failure = self.failures.pop(0); self.failure["t"] = max(self.failure["t"], float(t))
                i = self.failure["module"]
                tf = self.failure["t"]
                kind = self.failure.get("kind", "exit")
                if self.policy == "monolith" or (self.policy == "atlas" and self.c[i] == 0):
                    mode = "manual" if self.policy == "monolith" else self.o["heal"]
                    self.rec = Recovery(tf, heal_steps(p, rng, mode, pod=False, kind=kind),
                                        mode == "atlas")
                    self.rec.scope = "all"
                    if self.policy == "atlas":       # emergency Tight->Loose for the crashed module
                        self.apply(t, np.maximum(self.c, np.eye(self.n, dtype=int)[i]))
                else:
                    mode = self.o["heal"] if self.policy == "atlas" else "k8s"
                    self.rec = Recovery(tf, heal_steps(p, rng, mode, pod=True, kind=kind), mode == "atlas")
                    self.rec.scope = i
            # ---- performance
            v = p.visit; tight = self.c == 0
            lat, viol_frac, fail = self.perf(t, lam, d, net[t], tight)
            if self.policy == "monolith" or (tight.any() and self.mono_on):
                # crash rule for sustained monolith overload
                Dm = float((v * d)[tight].sum()); rho_m = lam * Dm / 1000 / p.mono_cores
                self.overload_s = self.overload_s + 1 if rho_m > p.crash_rho else 0
                if self.overload_s >= p.crash_hold_s and self.rec is None and self.mono_down_until < t:
                    mode = "manual" if self.policy == "monolith" else self.o["heal"]
                    self.rec = Recovery(float(t), heal_steps(p, rng, mode, pod=False), mode == "atlas")
                    self.rec.scope = "all"; self.overload_s = 0
                    if self.policy == "atlas":
                        self.apply(t, np.ones(self.n, int))
            # outage accounting
            if self.rec is not None:
                frac = self.rec.overlap(t)
                share = 1.0 if self.rec.scope == "all" else float(v[self.rec.scope])
                if frac > 0:
                    affected = lam * share * frac
                    if self.rec.buffered:
                        self.buffer = min(self.buffer + affected, p.buffer_cap)
                        overflow = max(0.0, affected - (p.buffer_cap - self.buffer))
                        fail += overflow; viol_frac = (viol_frac * lam + affected) / max(lam, 1)
                    else:
                        fail += affected
                if t + 1 >= self.rec.t_end:
                    self.log.append(dict(t_fail=self.rec.t_fail, mttd=self.rec.steps["detect"],
                                         mttr=self.rec.t_end - self.rec.t_fail, steps=self.rec.steps,
                                         buffered=float(self.buffer)))
                    self.flush = self.buffer; self.buffer = 0.0
                    self.rec = None
            out["lat"][t] = lat; out["lam"][t] = lam; out["viol"][t] = viol_frac
            out["fail"][t] = min(fail, lam); out["cost"][t] = self.cost(t, lam, tight)
            out["mode"][t] = 0 if self.c.sum() == 0 else (2 if self.c.sum() == self.n else 1)
        out["transitions"] = self.transitions; out["recoveries"] = self.log
        out["dec_ms"] = self.dec_ms
        return out

    def fsm_thresholds(self, lam):
        """Ablation: fixed thresholds (1000/5000 RPS) with a fixed hybrid set."""
        c = self.c.copy()
        if lam > 5000:
            return np.ones(self.n, int)
        if lam > 1000:
            c = np.zeros(self.n, int); c[[1, 2, 4]] = 1; return c
        return np.zeros(self.n, int)

    def score(self, t, lam, d):
        """Isolation-Forest score on telemetry synthesised from the simulator state."""
        p = self.p; tight = self.c == 0
        g = self.rng
        if tight.any():
            Dm = float((p.visit * d)[tight].sum()); rho = min(lam * Dm / 1000 / p.mono_cores, 0.99)
        else:
            rho = 0.5
        Dn = float((p.visit * p.demand).sum())
        cpu = min(100, 8 + 88 * rho + g.normal(0, 3)); lat = 12 + Dm / (1 - rho) if tight.any() else 60
        x = np.array([[lam, cpu, 35 + 30 * rho, lat, 0.002, 5 + 400 * max(rho - .8, 0),
                       0.004 * lam, 2.0]], dtype=np.float32)
        m = self.iforest
        s = -(m.get("fast") or m["model"]).score_samples(x)[0]
        a = float(np.clip((s - m["lo"]) / (m["hi"] - m["lo"]), 0, 1))
        # attribute anomaly to the module whose measured demand deviates most
        dev = d / p.demand
        self.anom_module = int(np.argmax(dev)) if dev.max() > 1.5 else -1
        return a

    def perf(self, t, lam, d, net, tight):
        p = self.p; v = p.visit
        fail = 0.0; lat = p.base_ms
        cloud = 0.0
        # monolith part
        if tight.any():
            Dm = float((v * d)[tight].sum())
            mu = p.mono_cores * 1000.0 / Dm
            rho = lam / mu
            if rho >= 1:
                self.backlog_m += lam - mu
            else:
                self.backlog_m = max(0.0, self.backlog_m - (mu - lam))
            cap = mu * p.timeout_s
            if self.backlog_m > cap:
                fail += self.backlog_m - cap; self.backlog_m = cap
            lat += Dm / (1 - min(rho, 0.95)) + 1000.0 * self.backlog_m / mu
        # loose services
        for i in np.where(~tight)[0]:
            li = lam * v[i]
            n_r = max(self.rep[i], 0)
            mu = n_r * self.cores[i] * 1000.0 / d[i] if n_r > 0 else 1e-9
            if self.policy == "xscale" and li > 0.9 * mu:
                cloud += (li - 0.9 * mu) * d[i] / 1000.0
                lat_i = d[i] / (1 - 0.9) + self.rng.uniform(*p.cloud_ms)
                self.backlog[i] = 0
            else:
                rho = li / mu
                if rho >= 1:
                    self.backlog[i] += li - mu
                else:
                    self.backlog[i] = max(0.0, self.backlog[i] - (mu - li))
                cap = mu * p.timeout_s
                if self.backlog[i] > cap:
                    fail += (self.backlog[i] - cap); self.backlog[i] = cap
                lat_i = d[i] / (1 - min(rho, 0.95)) + 1000.0 * self.backlog[i] / max(mu, 1e-9)
            lat += v[i] * (lat_i + net)
        if getattr(self, "barrier", 0):
            # hand-over pause: requests arriving inside it wait barrier/2 on average
            lat += (self.barrier / 1000.0) * (self.barrier / 2.0)
            self.barrier = 0
        self.cloud = cloud
        # flushing buffered requests after recovery adds queueing delay
        if self.flush > 0:
            extra = min(self.flush, lam * 0.5)
            self.flush -= extra
            lat += 50.0
        x = max(p.sla_ms - p.base_ms, 1.0); m = max(lat - p.base_ms, 1e-3)
        viol = math.exp(-x / m)
        return lat, viol, fail

    def cost(self, t, lam, tight):
        p = self.p
        c = p.mono_cores if self.mono_on else 0.0
        pods = self.rep + np.array([len(x) for x in self.pending])
        c += float((pods * (self.cores + p.sidecar_cores)).sum())
        c += float((self.c == 1).sum() + len(self.extract_ready)) * p.svc_fixed_cores
        c += lam * float(p.visit[~tight].sum()) * p.net_cost_core_s
        c += getattr(self, "cloud", 0.0) * p.cloud_price
        return c


def summarise(out, ref_cost=None, warm=300):
    lam = out["lam"][warm:]; lat = out["lat"][warm:]; v = out["viol"][warm:]
    f = out["fail"][warm:]
    tot = lam.sum()
    good = lam - f
    # request-weighted p99 of the mixture of shifted exponentials
    base = 10.0
    def tail(x):
        m = np.maximum(lat - base, 1e-3)
        return float((good * np.exp(-np.maximum(x - base, 0) / m)).sum()) / max(good.sum(), 1)
    lo, hi = 0.0, 1e5
    for _ in range(60):
        mid = (lo + hi) / 2
        lo, hi = (mid, hi) if tail(mid) > 0.01 else (lo, mid)
    res = dict(mean_ms=float((good * lat).sum() / max(good.sum(), 1)), p99_ms=hi,   # p99 over completed requests; failures reported separately
               sla_viol_pct=100 * float((good * v).sum() + f.sum()) / tot,
               failed_pct=100 * float(f.sum()) / tot,
               cost=float(out["cost"][warm:].mean()), transitions=out["transitions"])
    if ref_cost:
        res["rel_cost"] = res["cost"] / ref_cost
    rec = out["recoveries"]
    res["mttr_s"] = float(np.mean([r["mttr"] for r in rec])) if rec else float("nan")
    res["mttd_s"] = float(np.mean([r["mttd"] for r in rec])) if rec else float("nan")
    res["dec_ms"] = float(np.mean(out["dec_ms"])) if out["dec_ms"] else 0.0
    res["mode_share"] = [float((out["mode"][warm:] == k).mean()) for k in range(3)]
    return res


class FastIForest:
    """Single-sample Isolation-Forest scorer equivalent to
    sklearn's score_samples (path length + c(n) correction), ~50x faster
    for one row because it avoids joblib dispatch."""
    def __init__(self, model):
        self.trees = []
        for est, feats in zip(model.estimators_, model.estimators_features_):
            tr = est.tree_
            self.trees.append((tr.children_left, tr.children_right, tr.feature, tr.threshold,
                               tr.n_node_samples, np.asarray(feats)))
        self.cn = self._c(model._max_samples)

    @staticmethod
    def _c(n):
        if n <= 1: return 0.0
        if n == 2: return 1.0
        return 2.0 * (np.log(n - 1.0) + np.euler_gamma) - 2.0 * (n - 1.0) / n

    def score_samples(self, X):
        x = np.asarray(X, dtype=np.float32)[0]
        tot = 0.0
        for L, R, F, T, N, feats in self.trees:
            xs = x[feats]; node = 0; depth = 0
            while L[node] != -1:
                node = L[node] if xs[F[node]] <= T[node] else R[node]
                depth += 1
            tot += depth + self._c(N[node])
        return np.array([-(2.0 ** (-(tot / len(self.trees)) / self.cn))])
