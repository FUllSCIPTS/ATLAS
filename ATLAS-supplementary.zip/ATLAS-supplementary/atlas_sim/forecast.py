"""Traffic forecasters: trained LSTM / Bi-LSTM and statistical baselines."""
import time
import numpy as np
import torch
import torch.nn as nn
from sklearn.linear_model import Ridge

LOOKBACK = 60


class LSTMForecaster(nn.Module):
    def __init__(self, n_in, n_out, hidden=128, layers=2, dropout=0.2, bidirectional=False):
        super().__init__()
        self.lstm = nn.LSTM(n_in, hidden, layers, batch_first=True, dropout=dropout,
                            bidirectional=bidirectional)
        self.head = nn.Linear(hidden * (2 if bidirectional else 1), n_out)

    def forward(self, x):
        o, _ = self.lstm(x)
        return self.head(o[:, -1])


class Scaler:
    """Feature standardisation fitted on the training partition only."""
    def fit(self, F):
        self.mu = F.mean(0); self.sd = F.std(0) + 1e-6; return self

    def __call__(self, F):
        return (F - self.mu) / self.sd


def build_features(X8, cal):
    """X8: [n,8] telemetry (col0 = rps). Log-transform rate-like fields."""
    F = X8.copy().astype(np.float32)
    F[:, 0] = np.log1p(F[:, 0]); F[:, 6] = np.log1p(F[:, 6]); F[:, 5] = np.log1p(F[:, 5])
    return np.concatenate([F, cal], 1)


def windows(F, y_log, idx, horizons):
    """Return tensors for window end indices idx (inclusive)."""
    off = np.arange(-LOOKBACK + 1, 1)
    Xw = F[idx[:, None] + off[None, :]]
    Y = np.stack([y_log[idx + h] for h in horizons], 1)
    return torch.from_numpy(Xw), torch.from_numpy(Y.astype(np.float32))


def valid_idx(lo, hi, horizons):
    return np.arange(max(lo, LOOKBACK - 1), hi - max(horizons))


def train(F, y_log, tr, va, horizons, seed=0, bidirectional=False, max_epochs=100,
          patience=10, per_epoch=16384, batch=64, lr=1e-3, val_n=8192, log=print):
    torch.manual_seed(seed); rng = np.random.default_rng(seed)
    ymu, ysd = y_log[tr].mean(), y_log[tr].std()
    yn = ((y_log - ymu) / ysd).astype(np.float32)
    model = LSTMForecaster(F.shape[1], len(horizons), bidirectional=bidirectional)
    opt = torch.optim.Adam(model.parameters(), lr=lr)
    lossf = nn.MSELoss()
    vi = rng.choice(va, size=min(val_n, len(va)), replace=False)
    Xv, Yv = windows(F, yn, vi, horizons)
    best, best_state, bad, hist = 1e9, None, 0, []
    t0 = time.time()
    for ep in range(max_epochs):
        model.train()
        ti = rng.choice(tr, size=per_epoch, replace=False)
        for k in range(0, per_epoch, batch):
            Xb, Yb = windows(F, yn, ti[k:k + batch], horizons)
            opt.zero_grad(); l = lossf(model(Xb), Yb); l.backward()
            nn.utils.clip_grad_norm_(model.parameters(), 1.0); opt.step()
        model.eval()
        with torch.no_grad():
            vl = float(np.mean([lossf(model(Xv[i:i + 2048]), Yv[i:i + 2048]).item()
                                for i in range(0, len(vi), 2048)]))
        hist.append(vl)
        if vl < best - 1e-5:
            best, bad = vl, 0
            best_state = {k: v.clone() for k, v in model.state_dict().items()}
        else:
            bad += 1
        log(f"  epoch {ep+1:3d} val_mse={vl:.4f} best={best:.4f} ({time.time()-t0:.0f}s)")
        if bad >= patience:
            break
    model.load_state_dict(best_state)
    model.ymu, model.ysd = float(ymu), float(ysd)
    model.history = hist; model.epochs_run = ep + 1
    return model


def predict(model, F, idx, horizons, batch=4096):
    model.eval(); out = []
    off = np.arange(-LOOKBACK + 1, 1)
    with torch.no_grad():
        for k in range(0, len(idx), batch):
            ii = idx[k:k + batch]
            Xb = torch.from_numpy(F[ii[:, None] + off[None, :]])
            out.append(model(Xb).numpy())
    P = np.concatenate(out) * model.ysd + model.ymu
    return np.expm1(P)            # back to RPS


# --------------------------------------------------------------- baselines
def persistence(r, idx, horizons):
    return np.stack([r[idx] for _ in horizons], 1)


def seasonal_naive(r, idx, horizons, period=1440):
    return np.stack([r[np.maximum(idx + h - period, 0)] for h in horizons], 1)


def ar_features(r, cal, idx, h, lags=60):
    lr = np.log1p(r)
    L = lr[idx[:, None] - np.arange(lags)[None, :]]
    S = lr[np.maximum(idx + h - 1440, 0)][:, None]
    return np.concatenate([L, S, cal[idx]], 1)


def fit_ar(r, cal, tr, horizons, n=120000, seed=0):
    rng = np.random.default_rng(seed)
    ti = rng.choice(tr[tr >= 1440], size=min(n, len(tr)), replace=False)
    models = []
    for h in horizons:
        m = Ridge(alpha=1.0).fit(ar_features(r, cal, ti, h), np.log1p(r[ti + h]))
        models.append(m)
    return models


def predict_ar(models, r, cal, idx, horizons):
    return np.stack([np.expm1(m.predict(ar_features(r, cal, idx, h)))
                     for m, h in zip(models, horizons)], 1)


# ---------------------------------------------------------------- metrics
def metrics(y, p):
    e = p - y
    return dict(MAE=float(np.mean(np.abs(e))), RMSE=float(np.sqrt(np.mean(e ** 2))),
                MAPE=float(100 * np.mean(np.abs(e) / np.maximum(y, 1))))


def block_bootstrap_ci(y, p, block=1440, B=1000, seed=0, q=(2.5, 97.5)):
    """95% CI of MAPE with day-long blocks (preserves autocorrelation)."""
    rng = np.random.default_rng(seed)
    ape = 100 * np.abs(p - y) / np.maximum(y, 1)
    nb = len(ape) // block
    blocks = ape[:nb * block].reshape(nb, block).mean(1)
    bs = [blocks[rng.integers(0, nb, nb)].mean() for _ in range(B)]
    return [float(v) for v in np.percentile(bs, q)]


def surge_detection(r, p5, idx, thr, horizon=5, window=15):
    """Lead time (min) with which the t+5 forecast crosses `thr` before the
    actual series does, per surge episode; and false alarms per day."""
    act = r[idx + horizon] >= thr
    fc = p5 >= thr
    leads, hits, n_ep = [], 0, 0
    i = 1
    while i < len(idx):
        if act[i] and not act[i - 1]:
            n_ep += 1
            j0 = max(0, i - 30)
            seg = np.where(fc[j0:i + 1])[0]
            if len(seg):
                hits += 1; leads.append((i - (j0 + seg[0])) + horizon)
            while i < len(idx) and act[i]:
                i += 1
        i += 1
    # false alarm: forecast up-crossing with no actual exceedance within window
    fa = 0
    for i in range(1, len(idx)):
        if fc[i] and not fc[i - 1]:
            if not act[i:i + window].any():
                fa += 1
    days = len(idx) / 1440
    return dict(episodes=n_ep, detected=hits,
                lead_mean=float(np.mean(leads)) if leads else float("nan"),
                false_alarms_per_day=fa / days)
